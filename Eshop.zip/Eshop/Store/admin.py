from django.contrib import admin
from .models.Prdct import product
from .models.categoree import category
from .models.costumer import costumers
from .models.order import orders

class Adminorders(admin.ModelAdmin):
    list_display=['product','costumer','quantity','price','address','phone','date']

class Adminproduct(admin.ModelAdmin):
    list_display=['name','price','category']


class Admincategory(admin.ModelAdmin):
    list_display=['name']


class Admincostumers(admin.ModelAdmin):
    list_display=['firstname','lastname','phone','Email','password']


admin.site.register(product, Adminproduct)
admin.site.register(category, Admincategory)
admin.site.register(costumers, Admincostumers)
admin.site.register(orders, Adminorders)
