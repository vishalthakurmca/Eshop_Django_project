from django.db import models
from .categoree import category


class product(models.Model):
    name=models.CharField(max_length=50)
    price=models.FloatField(default=0.0)
    discription=models.CharField(max_length=200)
    image=models.ImageField(upload_to='uploads/products/')
    category=models.ForeignKey(category, on_delete=models.CASCADE, default=1)


    @staticmethod
    def get_product_byId(ids):
        return product.objects.filter(id__in=ids)

    @staticmethod
    def get_all_prducts(category_id):
        return product.objects.all();

    @staticmethod
    def get_all_prducts_by_categoryid(category_id):
        if category_id:
            return product.objects.filter(category=category_id);
        else:
            return product.get_all_prducts();
