from django.db import models

class costumers(models.Model):
    firstname=models.CharField(max_length=30)
    lastname=models.CharField(max_length=30)
    phone=models.CharField(max_length=10)
    Email=models.EmailField(max_length=40)
    password=models.CharField(max_length=400)

    @staticmethod
    def get_custmer_by_Email(Email):
        try:
            return costumers.objects.get(Email=Email)
        except:
            return False


    def register(self):
        self.save()


    def isExists(self):
        if costumers.objects.filter(Email=self.Email):
            return True
        return False
