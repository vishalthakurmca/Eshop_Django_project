from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password , check_password
from .models import Prdct
from .models import categoree
from .models import costumers
from .models import order
from django.http import HttpResponseRedirect,HttpResponse
from django.views import View

class orderview(View):
    def get(self,request):
        COSTMER=request.session.get('customer')
        ORDER=order.orders.get_order_by_customer(COSTMER)
        print(ORDER)
        return render(request,'Store/order.html',{'ORDER':ORDER})

class checkout(View):
    def post(self,request):
        address=request.POST.get('address')
        phone=request.POST.get('phone')
        costomer=request.session.get('customer')
        cart=request.session.get('cart')
        products=Prdct.product.get_product_byId(list(cart.keys()))
        
        for product in products:
            ORDER=order.orders(costumer=costumers(id=costomer),
            product=product,
            price=product.price,
            address=address,
            phone=phone,
            quantity=cart.get(str(product.id)))
            ORDER.save()
        request.session['cart']={}
        return redirect('cart')

def logout(request):
    request.session.clear()
    return redirect('login')

class carts(View):
    def get(self,request):
        ids=list(request.session.get('cart').keys())
        products=Prdct.product.get_product_byId(ids)
        return render(request,'Store/carts.html',{'products':products})

class loginacount(View):
    return_url=None
    def get(self,request):
        loginacount.return_url=request.GET.get('return_url')
        return render(request,'Store/login.html')
    def post(self,request):
        Email=request.POST.get('Email')
        password=request.POST.get('password')
        COSTUMER=costumers.get_custmer_by_Email(Email)
        error=None
        if COSTUMER:
            Flag=check_password(password,COSTUMER.password)
            if Flag:
                request.session['customer']=COSTUMER.id
                if loginacount.return_url:
                    return HttpResponseRedirect(loginacount.return_url)
                else:
                    loginacount.return_url=None
                    return redirect('homepage')
            else:
                error='Email or Password invalid!!'
        else:
            error='Email or Password invalid!!'
        return render(request,'Store/login.html',{'error':error})
        



class showsignup(View):
    def get(self,request):
        return render(request,'Store/signup.html')
    def post(self,request):
        PostData=request.POST
        firstname=PostData.get('firstname')
        lastname=PostData.get('lastname')
        phone=PostData.get('phone')
        Email=PostData.get('Email')
        password=PostData.get('password')
        reenterpassword=PostData.get('reenterpassword')
    #values
        values={'firstname':firstname,'lastname':lastname,'phone':phone,'Email':Email}
        COSTUMER=costumers(
        firstname=firstname,
        lastname=lastname,
        phone=phone,
        Email=Email,
        password=password,
        )
        error=self.validatecostmur(COSTUMER,reenterpassword)
        if error:
            return render(request,'Store/signup.html',{'error':error,'values':values})
        else:
            COSTUMER.password=make_password(COSTUMER.password)
            COSTUMER.register()
            return redirect('homepage')
    def validatecostmur(self,cousmer,reenterpassword):
     #validtetion
        error_msg=None
        if not cousmer.firstname:
            error_msg="First Name must be required!"
        elif not cousmer.lastname:
            error_msg="Last Name must be required!"
        elif 10!=len(cousmer.phone):
            error_msg="phone number is not valid! Enter must be 10 digit mobile number."
        elif cousmer.password!=reenterpassword:
           error_msg="password does Not match!"
        elif 6>len(cousmer.password):
            error_msg="password must have at least 6 charecter!"
        elif cousmer.isExists():
            error_msg='Email Address Already Registered!'
            #endvalidtion
        return error_msg

class index(View):
    def get(self,request):
        cart=request.session.get('cart')
        if not cart:
            request.session['cart']={}
        products= None
        categorys=categoree.category.objects.all()
        categoryID=request.GET.get('category')
        if categoryID:
          products=Prdct.product.get_all_prducts_by_categoryid(categoryID)
        else:
            products=Prdct.product.get_all_prducts(categoryID)
        print('you are:',request.session.get('Email'))
        return render(request,'Store/index.html',{'products':products,'categorys':categorys})  
    def post(self,request):
        product=request.POST.get('product')
        cart=request.session.get('cart')
        remove=request.POST.get('remove')
        if cart:
            quantity=cart.get(product)
            if quantity:
                if remove:
                    if quantity<=1:
                        cart.pop(product)
                    else:
                        cart[product]=quantity-1
                else:
                    cart[product]=quantity+1
            else:
                cart[product]=1
        else:
            cart={}
            cart[product]=1
        request.session['cart']=cart
        return redirect('homepage')
       
