from django.conf.urls import url
from django.urls import path
from Store import views
from .middleware.auth import auth_middleware

urlpatterns=[
url('index',views.index.as_view(),name='homepage'),
url('signupform',views.showsignup.as_view()),
url('login',views.loginacount.as_view(),name='login'),
url('logout',views.logout),
url('carts',views.carts.as_view(),name='cart'),
url('checkout',views.checkout.as_view()),
url('orderr',auth_middleware(views.orderview.as_view()),name='orderr'),
]
